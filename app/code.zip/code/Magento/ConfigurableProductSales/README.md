# Magento_ConfigurableProductSales module

The Magento_ConfigurableProductSales module checks that the selected options of order item are still presented in
Catalog. Returns true if the previously ordered item configuration is still available. 