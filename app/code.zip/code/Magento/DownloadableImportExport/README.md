The Magento_DownloadableImportExport module handles the import and export of the downloadable products.
