GoogleAdwords is a module designed for integration of Google Adwords service.
