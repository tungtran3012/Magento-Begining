# Integration

**Integration** enables third-party services to call the Web API by using access tokens.
It provides an admin UI that enables manual creation of integrations. Extensions can also provide a configuration
file so that an integration can be automatically pre-configured. The module also contains the data
model for request and access token management.
