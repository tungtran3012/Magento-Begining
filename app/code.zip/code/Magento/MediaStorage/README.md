The Magento_MediaStorage module implements functionality related with upload media files and synchronize it by database.
