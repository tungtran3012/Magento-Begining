The Magento_OfflinePayments module implements the payment methods which do not require interaction with a payment gateway (so called offline methods). These methods are the following:
*Bank transfer
*Cash on delivery
*Check / Money Order
*Purchase order
