The Magento_Swagger module provides access to a page generated using the swagger-ui package. The swagger-ui can be viewed
[on Github](https://github.com/swagger-api/swagger-ui). It accesses the JSON Schema describing Magento's REST APIs,
and displays it in a user-friendly, navigable format.
