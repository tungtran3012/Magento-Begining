<?php
/**
 * Created by PhpStorm.
 * User: morph
 * Date: 17/01/2019
 * Time: 16:55
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Packt_SEO',
    __DIR__
);

